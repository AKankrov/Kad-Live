from .parcel import ParcelView
from .update import UpdateView

__all__ = (ParcelView, UpdateView)
