from django.apps import AppConfig


class CadinfoConfig(AppConfig):
    name = 'cadinfo'
